document.addEventListener("DOMContentLoaded", () => {
  console.log("Sivu ladattu!");
});